package PVE::API2::NodeRemoval;

use strict;
use warnings;

use PVE::JSONSchema qw(get_standard_option);
use PVE::RESTHandler;
use PVE::NodeRemoval;
use PVE::AccessControl;

use base qw(PVE::RESTHandler);

=head1 PVE::API2::NodeRemoval

REST API endpoints for node removal operations.

=cut

__PACKAGE__->register_method ({
    name => 'list_removable_nodes',
    path => '/cluster/nodes-removal',
    method => 'GET',
    protected => 1,
    permissions => { check => ['perm', '/nodes', ['Sys.Audit']] },
    description => "List nodes available for removal.",
    returns => {
        type => 'array',
        items => {
            type => 'object',
            properties => {
                node => { type => 'string' },
                status => { type => 'string' },
                vms => { type => 'integer' },
                warnings => { type => 'array' },
            },
        },
    },
    code => sub {
        my ($param) = @_;
        
        my $nodes = PVE::Cluster::get_nodelist();
        my $result = [];
        
        foreach my $nodename (@$nodes) {
            my $validation = PVE::NodeRemoval::validate_node_removal($nodename);
            my $status = PVE::NodeRemoval::get_removal_status($nodename);
            
            push @$result, {
                node => $nodename,
                valid => $validation->{valid},
                warnings => $validation->{warnings},
                vms => scalar(@{$status->{vms}}),
                online => $status->{online},
            };
        }
        
        return $result;
    }
});

__PACKAGE__->register_method ({
    name => 'node_removal_status',
    path => '/cluster/nodes-removal/{nodename}',
    method => 'GET',
    protected => 1,
    permissions => { check => ['perm', '/nodes/{nodename}', ['Sys.Audit']] },
    description => "Get detailed status of a node before removal.",
    parameters => {
        additionalProperties => 0,
        properties => {
            nodename => get_standard_option('pve-node'),
        },
    },
    returns => {
        type => 'object',
        properties => {
            node => { type => 'string' },
            vms => { type => 'array' },
            storage => { type => 'array' },
            online => { type => 'boolean' },
            validation => { type => 'object' },
        },
    },
    code => sub {
        my ($param) = @_;
        my $nodename = $param->{nodename};
        
        my $validation = PVE::NodeRemoval::validate_node_removal($nodename);
        my $status = PVE::NodeRemoval::get_removal_status($nodename);
        
        return {
            %$status,
            validation => $validation,
        };
    }
});

__PACKAGE__->register_method ({
    name => 'drain_node',
    path => '/cluster/nodes-removal/{nodename}/drain',
    method => 'POST',
    protected => 1,
    permissions => { check => ['perm', '/nodes/{nodename}', ['Sys.Modify']] },
    description => "Migrate all VMs/containers from a node.",
    parameters => {
        additionalProperties => 0,
        properties => {
            nodename => get_standard_option('pve-node'),
            'migration-target' => {
                type => 'string',
                description => 'Target node for VM migration (optional, auto-select if not specified)',
                optional => 1,
            },
        },
    },
    returns => {
        type => 'object',
        properties => {
            migrated => { type => 'array' },
            failed => { type => 'array' },
        },
    },
    code => sub {
        my ($param) = @_;
        my $nodename = $param->{nodename};
        my $target = $param->{'migration-target'};
        
        if (!$target) {
            # Auto-select a target node (preferably not the one being removed)
            my $nodes = PVE::Cluster::get_nodelist();
            $target = (grep { $_ ne $nodename } @$nodes)[0];
        }
        
        return PVE::NodeRemoval::drain_node($nodename, $target);
    }
});

__PACKAGE__->register_method ({
    name => 'remove_node',
    path => '/cluster/nodes-removal/{nodename}',
    method => 'DELETE',
    protected => 1,
    permissions => { check => ['perm', '/nodes/{nodename}', ['Sys.Modify']] },
    description => "Remove a node from the cluster.",
    parameters => {
        additionalProperties => 0,
        properties => {
            nodename => get_standard_option('pve-node'),
            force => {
                type => 'boolean',
                description => 'Force removal even if validation checks fail',
                optional => 1,
                default => 0,
            },
            'dry-run' => {
                type => 'boolean',
                description => 'Only validate, do not actually remove',
                optional => 1,
                default => 0,
            },
        },
    },
    returns => {
        type => 'object',
        properties => {
            success => { type => 'boolean' },
            node => { type => 'string' },
        },
    },
    code => sub {
        my ($param) = @_;
        my $nodename = $param->{nodename};
        my $force = $param->{force} // 0;
        my $dry_run = $param->{'dry-run'} // 0;
        
        my $validation = PVE::NodeRemoval::validate_node_removal($nodename);
        
        if ($dry_run) {
            return {
                success => $validation->{valid},
                validation => $validation,
                node => $nodename,
            };
        }
        
        return PVE::NodeRemoval::remove_node($nodename, $force);
    }
});

1;
