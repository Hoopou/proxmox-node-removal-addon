// Proxmox Node Removal Tool - Cluster Tab
// 
// This creates a new tab in the Cluster section of Proxmox web UI

Ext.define('PVE.cluster.NodeRemovalToolTab', {
    extend: 'Ext.panel.Panel',
    
    title: 'Node Removal Tool',
    layout: 'fit',
    iconCls: 'fa fa-exchange',
    
    initComponent: function() {
        let me = this;
        
        me.items = [
            Ext.create('PVE.NodeRemovalPanel')
        ];
        
        me.callParent();
    }
});

// Register in the Cluster tabs
Ext.define('PVE.ClusterTabs', {
    override: 'PVE.ClusterStatusView',
    
    initComponent: function() {
        let me = this;
        
        me.callParent();
        
        // Add Node Removal Tool tab after other tabs
        if (me.items && me.items.items) {
            me.add({
                xtype: 'panel',
                title: 'Node Removal Tool',
                layout: 'fit',
                items: [
                    Ext.create('PVE.NodeRemovalPanel')
                ]
            });
        }
    }
});
